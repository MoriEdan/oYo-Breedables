ALTER TABLE  #__breedable CHANGE  breedable_walk  breedable_walk INT( 1 ) NOT NULL;
ALTER TABLE  #__breedable CHANGE  breedable_terrain  breedable_terrain INT( 1 ) NOT NULL;
ALTER TABLE  #__breedable CHANGE  breedable_sound  breedable_sound INT( 1 ) NOT NULL;
ALTER TABLE  #__breedable CHANGE  breedable_title  breedable_title INT( 1 ) NOT NULL;
ALTER TABLE  #__breedable CHANGE  breedable_mate  breedable_mate INT( 1 ) NOT NULL;